    #include<stdio.h>
    void main()
    {
        int A[3][3],B[3][3],C[3][3],I,J;
        printf("ENTER 3X3 MATRIX A VALUES\n");
        for(I=0;I<3;I++)
        {
            for(J=0;J<3;J++)
            {
                scanf("%d",&A[I][J]);
            }
        }
        printf("ENTER 3X3 MATRIX B VALUES\n");
        for(I=0;I<3;I++)
        {
            for(J=0;J<3;J++)
            {
                scanf("%d",&B[I][J]);
            }
        }
        for(I=0;I<3;I++)
        {
            for(J=0;J<3;J++)
            {
                C[I][J]=A[I][J]+B[I][J];
            }
        }
        printf("RESULT 3X3 MATRIX C VALUES ARE :\n");
        for(I=0;I<3;I++)
        {
            for(J=0;J<3;J++)
            {
                printf("%d\t",C[I][J]);
            }
            printf("\n");
        }
    }