#include<stdio.h>
int main()
{
    float r, a ,v;
    printf("enter radius :\n");
    scanf("%f", &r);
    a = 3.14*r*r;
    v=4/3*22/7*r*r*r;
    printf("Area = %f\n volume of Sphere = %f\n",a,v);
    return 0;
}